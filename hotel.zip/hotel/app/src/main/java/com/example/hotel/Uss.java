package com.example.hotel;

public class Uss {
    String room;


    public Uss() {

    }

    public Uss(String room) {
        this.room = room;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }
}
